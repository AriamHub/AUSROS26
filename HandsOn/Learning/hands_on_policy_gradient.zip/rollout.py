import numpy as np
import torch


class RolloutBuffer:
    """Stores one or more episodes and computes GAE advantages / returns.

    Shared by REINFORCE and PPO: passing lam=1.0 recovers the plain
    Monte-Carlo return used by REINFORCE, while lam<1 gives the usual
    bias/variance trade-off used by PPO.
    """

    def __init__(self):
        self.clear()

    def clear(self):
        self.obs, self.actions, self.log_probs = [], [], []
        self.rewards, self.values, self.dones = [], [], []

    def add(self, obs, action, log_prob, reward, value, done):
        self.obs.append(obs)
        self.actions.append(action)
        self.log_probs.append(log_prob)
        self.rewards.append(reward)
        self.values.append(value)
        self.dones.append(done)

    def as_tensors(self):
        obs = torch.as_tensor(np.array(self.obs), dtype=torch.float32)
        actions = torch.stack(self.actions)
        log_probs = torch.stack(self.log_probs)
        return obs, actions, log_probs

    def compute_returns_and_advantages(self, last_value=0.0, gamma=0.99, lam=0.95):
        values = self.values + [last_value]
        advantages = np.zeros(len(self.rewards), dtype=np.float32)
        gae = 0.0
        for t in reversed(range(len(self.rewards))):
            mask = 1.0 - float(self.dones[t])
            delta = self.rewards[t] + gamma * values[t + 1] * mask - values[t]
            gae = delta + gamma * lam * mask * gae
            advantages[t] = gae
        returns = advantages + np.array(self.values, dtype=np.float32)
        return torch.as_tensor(returns), torch.as_tensor(advantages)
