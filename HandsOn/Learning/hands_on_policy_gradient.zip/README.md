# hands-on-ppo

## Install uv

macOS / Linux:

```sh
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Windows (PowerShell):

```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

Or via pip:

```sh
pip install uv
```

## Create and activate the virtual environment

Create the venv and install dependencies from `pyproject.toml`:

```sh
uv sync
```

Activate it:

- macOS / Linux: `source .venv/bin/activate`
- Windows (PowerShell): `.venv\Scripts\Activate.ps1`
- Windows (cmd): `.venv\Scripts\activate.bat`

Or run commands without activating:

```sh
uv run python main.py
```
