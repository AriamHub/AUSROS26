import torch
import torch.nn.functional as F
import torch.optim as optim

from networks import PolicyNetwork, ValueNetwork


class PPOAgent:
    """Proximal Policy Optimization with a clipped surrogate objective and GAE."""

    def __init__(self, obs_dim, action_space, lr=3e-4, hidden_size=64,
                 clip_ratio=0.2, epochs=10, entropy_coef=0.0, value_coef=0.5):
        self.policy = PolicyNetwork(obs_dim, action_space, hidden_size)
        self.value = ValueNetwork(obs_dim, hidden_size)
        params = list(self.policy.parameters()) + list(self.value.parameters())
        self.optimizer = optim.Adam(params, lr=lr)
        self.clip_ratio = clip_ratio
        self.epochs = epochs
        self.entropy_coef = entropy_coef
        self.value_coef = value_coef

    def act(self, obs):
        obs = torch.as_tensor(obs, dtype=torch.float32)
        with torch.no_grad():
            action, log_prob = self.policy.act(obs)
            value = self.value(obs)
        return action, log_prob, value.item()

    def act_deterministic(self, obs):
        obs = torch.as_tensor(obs, dtype=torch.float32)
        return self.policy.act_deterministic(obs)

    def update(self, buffer, gamma=0.99, lam=0.95):
        obs, actions, old_log_probs = buffer.as_tensors()
        returns, advantages = buffer.compute_returns_and_advantages(0.0, gamma, lam)
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        for _ in range(self.epochs):
            dist = self.policy(obs)
            log_probs = dist.log_prob(actions)
            entropy = dist.entropy()
            if not self.policy.discrete:
                log_probs = log_probs.sum(-1)
                entropy = entropy.sum(-1)

            ratio = (log_probs - old_log_probs).exp()
            clipped_ratio = torch.clamp(ratio, 1 - self.clip_ratio, 1 + self.clip_ratio)
            policy_loss = -torch.min(ratio * advantages, clipped_ratio * advantages).mean()

            values = self.value(obs)
            value_loss = F.mse_loss(values, returns)

            loss = policy_loss + self.value_coef * value_loss - self.entropy_coef * entropy.mean()

            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

        return {"policy_loss": policy_loss.item(), "value_loss": value_loss.item()}
