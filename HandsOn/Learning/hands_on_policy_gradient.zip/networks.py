import torch
import torch.nn as nn
from torch.distributions import Categorical, Normal


def build_mlp(input_dim, output_dim, hidden_size=64, n_hidden=2):
    layers = []
    last_dim = input_dim
    for _ in range(n_hidden):
        layers += [nn.Linear(last_dim, hidden_size), nn.Tanh()]
        last_dim = hidden_size
    layers.append(nn.Linear(last_dim, output_dim))
    return nn.Sequential(*layers)


class PolicyNetwork(nn.Module):
    """Actor network. Outputs a Categorical distribution for discrete action
    spaces or a diagonal Gaussian for continuous ones."""

    def __init__(self, obs_dim, action_space, hidden_size=64):
        super().__init__()
        self.discrete = hasattr(action_space, "n")
        act_dim = action_space.n if self.discrete else action_space.shape[0]
        self.net = build_mlp(obs_dim, act_dim, hidden_size)
        if not self.discrete:
            self.log_std = nn.Parameter(torch.zeros(act_dim))

    def forward(self, obs):
        out = self.net(obs)
        if self.discrete:
            return Categorical(logits=out)
        return Normal(out, self.log_std.exp())

    def act(self, obs):
        dist = self.forward(obs)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        if not self.discrete:
            log_prob = log_prob.sum(-1)
        return action, log_prob

    def act_deterministic(self, obs):
        with torch.no_grad():
            if self.discrete:
                return self.net(obs).argmax(-1)
            return self.net(obs)


class ValueNetwork(nn.Module):
    """Critic / baseline network estimating state value."""

    def __init__(self, obs_dim, hidden_size=64):
        super().__init__()
        self.net = build_mlp(obs_dim, 1, hidden_size)

    def forward(self, obs):
        return self.net(obs).squeeze(-1)
