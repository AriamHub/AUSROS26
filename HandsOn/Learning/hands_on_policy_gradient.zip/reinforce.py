import torch
import torch.nn.functional as F
import torch.optim as optim

from networks import PolicyNetwork, ValueNetwork


class ReinforceAgent:
    """REINFORCE with a learned value-function baseline."""

    def __init__(self, obs_dim, action_space, lr=3e-3, hidden_size=64):
        self.policy = PolicyNetwork(obs_dim, action_space, hidden_size)
        self.value = ValueNetwork(obs_dim, hidden_size)
        params = list(self.policy.parameters()) + list(self.value.parameters())
        self.optimizer = optim.Adam(params, lr=lr)

    def act(self, obs):
        obs = torch.as_tensor(obs, dtype=torch.float32)
        with torch.no_grad():
            action, log_prob = self.policy.act(obs)
            value = self.value(obs)
        return action, log_prob, value.item()

    def act_deterministic(self, obs):
        obs = torch.as_tensor(obs, dtype=torch.float32)
        return self.policy.act_deterministic(obs)

    def update(self, buffer, gamma=0.99):
        obs, actions, _ = buffer.as_tensors()
        returns, _ = buffer.compute_returns_and_advantages(last_value=0.0, gamma=gamma, lam=1.0)

        values = self.value(obs)
        advantages = (returns - values).detach()

        dist = self.policy(obs)
        log_probs = dist.log_prob(actions)
        if not self.policy.discrete:
            log_probs = log_probs.sum(-1)

        policy_loss = -(log_probs * advantages).mean()
        value_loss = F.mse_loss(values, returns)
        loss = policy_loss + value_loss

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return {"policy_loss": policy_loss.item(), "value_loss": value_loss.item()}
