import argparse
import os
import subprocess
import sys

import gymnasium as gym
import matplotlib.pyplot as plt
import numpy as np
import torch

from ppo import PPOAgent
from reinforce import ReinforceAgent
from rollout import RolloutBuffer


def parse_args():
    p = argparse.ArgumentParser(description="Train REINFORCE or PPO on a Gymnasium task.")
    p.add_argument("--algo", choices=["reinforce", "ppo"], default="ppo")
    p.add_argument("--env", default="CartPole-v1")
    p.add_argument("--iterations", type=int, default=20)
    p.add_argument("--episodes-per-update", type=int, default=4)
    p.add_argument("--lr", type=float, default=3e-3)
    p.add_argument("--gamma", type=float, default=0.99)
    p.add_argument("--gae-lambda", type=float, default=0.95)
    p.add_argument("--hidden-size", type=int, default=64)
    p.add_argument("--clip-ratio", type=float, default=0.2)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--entropy-coef", type=float, default=0.0)
    p.add_argument("--eval-episodes", type=int, default=10)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out-dir", default="results")
    p.add_argument("--record", action="store_true",
                   help="Record a video of a deterministic rollout after every iteration.")
    p.add_argument("--open-video", action="store_true",
                   help="Pop each recorded video open in the default player.")
    p.add_argument("--video-dir", default=os.path.join("results", "videos"))
    p.add_argument("--video-every", type=int, default=4,
                   help="Record/pop a video every N iterations (the final iteration is always recorded).")
    p.add_argument("--video-fps", type=int, default=30)
    return p.parse_args()


def to_env_action(action):
    action = action.numpy()
    return action.item() if action.ndim == 0 else action


def run_episode(env, agent, buffer):
    obs, _ = env.reset()
    done = False
    episode_return = 0.0
    while not done:
        action, log_prob, value = agent.act(obs)
        next_obs, reward, terminated, truncated, _ = env.step(to_env_action(action))
        done = terminated or truncated
        buffer.add(obs, action, log_prob, reward, value, done)
        obs = next_obs
        episode_return += reward
    return episode_return


def evaluate(env, agent, n_episodes):
    returns = []
    for _ in range(n_episodes):
        obs, _ = env.reset()
        done = False
        total = 0.0
        while not done:
            action = agent.act_deterministic(obs)
            obs, reward, terminated, truncated, _ = env.step(to_env_action(action))
            done = terminated or truncated
            total += reward
        returns.append(total)
    return returns


def record_rollout(render_env, agent, path, fps=30):
    """Run one deterministic episode, encode the frames to an mp4 with ffmpeg."""
    obs, _ = render_env.reset()
    frames = [render_env.render()]
    done = False
    total = 0.0
    while not done:
        action = agent.act_deterministic(obs)
        obs, reward, terminated, truncated, _ = render_env.step(to_env_action(action))
        done = terminated or truncated
        total += reward
        frames.append(render_env.render())

    h, w, _ = frames[0].shape
    cmd = [
        "ffmpeg", "-y", "-loglevel", "error",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(fps),
        "-i", "-", "-an", "-vcodec", "libx264", "-pix_fmt", "yuv420p", path,
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for frame in frames:
        proc.stdin.write(np.ascontiguousarray(frame, dtype=np.uint8).tobytes())
    proc.stdin.close()
    proc.wait()
    return total


def open_file(path):
    """Pop a file open in the OS default application."""
    if sys.platform == "darwin":
        subprocess.Popen(["open", path])
    elif sys.platform.startswith("win"):
        os.startfile(path)  # type: ignore[attr-defined]
    else:
        subprocess.Popen(["xdg-open", path])


def build_agent(args, obs_dim, action_space):
    if args.algo == "reinforce":
        return ReinforceAgent(obs_dim, action_space, lr=args.lr, hidden_size=args.hidden_size)
    return PPOAgent(
        obs_dim, action_space, lr=args.lr, hidden_size=args.hidden_size,
        clip_ratio=args.clip_ratio, epochs=args.epochs, entropy_coef=args.entropy_coef,
    )


def plot_results(train_returns, eval_returns, args):
    os.makedirs(args.out_dir, exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))

    axes[0].plot(train_returns, color="#4C72B0")
    axes[0].set_title("Training return per iteration")
    axes[0].set_xlabel("Iteration")
    axes[0].set_ylabel("Episode return")

    axes[1].boxplot(eval_returns)
    axes[1].scatter(np.ones(len(eval_returns)), eval_returns, alpha=0.6, color="#DD8452")
    axes[1].set_title(f"Evaluation returns (n={len(eval_returns)})")
    axes[1].set_xticks([])
    axes[1].set_ylabel("Episode return")

    fig.suptitle(f"{args.algo.upper()} on {args.env}")
    fig.tight_layout()
    path = os.path.join(args.out_dir, f"{args.algo}_{args.env}.png")
    fig.savefig(path, dpi=150)
    print(f"Saved plot to {path}")


def main():
    args = parse_args()
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    env = gym.make(args.env)
    obs_dim = env.observation_space.shape[0]
    agent = build_agent(args, obs_dim, env.action_space)
    buffer = RolloutBuffer()

    # Seed each env's RNG once; later reset() calls stream deterministically from it.
    env.reset(seed=args.seed)
    env.action_space.seed(args.seed)

    render_env = None
    if args.record:
        render_env = gym.make(args.env, render_mode="rgb_array")
        render_env.reset(seed=args.seed + 1)
        os.makedirs(args.video_dir, exist_ok=True)

    update_kwargs = {"gamma": args.gamma}
    if args.algo == "ppo":
        update_kwargs["lam"] = args.gae_lambda

    train_returns = []
    log_every = max(1, args.iterations // 20)
    for iteration in range(1, args.iterations + 1):
        buffer.clear()
        iter_returns = [run_episode(env, agent, buffer) for _ in range(args.episodes_per_update)]
        agent.update(buffer, **update_kwargs)
        train_returns.append(float(np.mean(iter_returns)))
        if iteration % log_every == 0:
            print(f"Iter {iteration:4d} | avg return {train_returns[-1]:7.2f}")

        if render_env is not None and (iteration % args.video_every == 0 or iteration == args.iterations):
            video_path = os.path.join(args.video_dir, f"{args.algo}_{args.env}_iter{iteration:04d}.mp4")
            vid_return = record_rollout(render_env, agent, video_path, fps=args.video_fps)
            print(f"Iter {iteration:4d} | recorded rollout (return {vid_return:6.1f}) -> {video_path}")
            if args.open_video:
                open_file(video_path)

    if render_env is not None:
        render_env.close()

    eval_env = gym.make(args.env)
    eval_env.reset(seed=args.seed + 2)
    eval_returns = evaluate(eval_env, agent, args.eval_episodes)
    print(f"Evaluation over {args.eval_episodes} episodes: mean={np.mean(eval_returns):.2f}")

    plot_results(train_returns, eval_returns, args)


if __name__ == "__main__":
    main()
